
document.addEventListener("DOMContentLoaded", () => {
  // Animate banner title with GSAP
  gsap.from(".banner-title", {
    duration: 1,
    y: 50,
    opacity: 0,
    ease: "power3.out"
  });

  // Animate founder section with Anime.js
  anime({
    targets: '.curved-box',
    translateY: [100, 0],
    opacity: [0, 1],
    duration: 1200,
    easing: 'easeOutExpo',
    delay: 500
  });

  // Parallax effect with Rellax (if used later)
  // const rellax = new Rellax('.rellax');

  // Smooth transitions with Barba.js (example)
  barba.init({
    transitions: [{
      name: 'fade',
      leave(data) {
        return gsap.to(data.current.container, {
          opacity: 0,
          duration: 0.5
        });
      },
      enter(data) {
        return gsap.from(data.next.container, {
          opacity: 0,
          duration: 0.5
        });
      }
    }]
  });
});

  // Animate features and facts
  anime({
    targets: '.feature-card, .fact-box',
    translateY: [50, 0],
    opacity: [0, 1],
    duration: 800,
    easing: 'easeOutQuad',
    delay: anime.stagger(200)
  });
